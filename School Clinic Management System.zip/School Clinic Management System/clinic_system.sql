-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2024 at 10:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinic_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `patientreport_tbl`
--

CREATE TABLE `patientreport_tbl` (
  `patientID` varchar(10) NOT NULL,
  `symptom` varchar(200) DEFAULT NULL,
  `diagnosis` varchar(200) DEFAULT NULL,
  `medicines` varchar(200) DEFAULT NULL,
  `conReq` varchar(5) DEFAULT NULL,
  `conType` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patientreport_tbl`
--

INSERT INTO `patientreport_tbl` (`patientID`, `symptom`, `diagnosis`, `medicines`, `conReq`, `conType`) VALUES
('1', 'pmaol', 'hilot', 'kamunggay', 'YES', 'Monoblock Chair'),
('2', 'Hello', 'Hello', 'Hello', 'NO', ''),
('2022-6214', 'Headache', 'Headshot', 'Lagundi 3xday', 'YES', 'Monoblock Chair'),
('4', 'Pamaol', 'Pain', 'PainKillers', 'NO', ''),
('6', 'Flu', 'Heavy Breathing', 'Paracetamol', 'NO', '');

-- --------------------------------------------------------

--
-- Table structure for table `patient_tbl`
--

CREATE TABLE `patient_tbl` (
  `patientID` varchar(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `contactNumber` varchar(11) DEFAULT NULL,
  `age` varchar(3) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `bloodType` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `purposeOfVisit` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_tbl`
--

INSERT INTO `patient_tbl` (`patientID`, `name`, `contactNumber`, `age`, `gender`, `bloodType`, `address`, `purposeOfVisit`) VALUES
('1', 'Jerahmeel', '09836365771', '20', 'Male', 'O+', 'Purok 4 Rang-ay,Banaybanay', 'Headache and Flu'),
('2', 'Joash', '09364758333', '2', 'Male', 'O+', 'Banaybanay', 'Lacerations'),
('2022-3542', 'Jareth', '09313112122', '21', 'Male', 'O+', 'Manikling', 'Headache'),
('2022-6214', 'Daniela Padilla', '09643873637', '25', 'Female', 'A+', 'Manila', 'Carbon Check'),
('3', 'Ana', '09657634553', '7', 'Female', 'O', 'Mati', 'Consultation'),
('4', 'John Bagcal', '09273648223', '14', 'Male', 'A+', 'Banaybanay City', 'Dental'),
('6', 'Jerahmeel', '09094356774', '20', 'Male', 'O', 'Lupon', 'Fever and Cramps');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patientreport_tbl`
--
ALTER TABLE `patientreport_tbl`
  ADD PRIMARY KEY (`patientID`);

--
-- Indexes for table `patient_tbl`
--
ALTER TABLE `patient_tbl`
  ADD PRIMARY KEY (`patientID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
